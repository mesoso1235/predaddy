/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  COLUMN_ARTICLES, 
  ColumnArticle 
} from '../data/columnData';
import { 
  BookOpen, 
  MagnifyingGlass, 
  CalendarBlank, 
  FirstAid, 
  Heartbeat, 
  House, 
  Users, 
  Sparkle, 
  X, 
  CheckSquare, 
  Warning, 
  ShareNetwork,
  ClipboardText
} from '@phosphor-icons/react';

export default function ColumnTab() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'preparation' | 'health' | 'life' | 'relationship'>('all');
  const [activeArticle, setActiveArticle] = useState<ColumnArticle | null>(null);
  
  // Highlighting "Daddy's TODOs" checked State (persisted in session / locally)
  const [completedTodos, setCompletedTodos] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('prepapa_column_todos_v1');
    return saved ? JSON.parse(saved) : {};
  });

  const toggleTodo = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = {
      ...completedTodos,
      [id]: !completedTodos[id]
    };
    setCompletedTodos(updated);
    localStorage.setItem('prepapa_column_todos_v1', JSON.stringify(updated));
  };

  const handleShare = () => {
    // Elegant toast or trigger alternative within Sandbox limits
    alert("お好みのSNSや、パートナー宛てのLINEにこのコラムへのリンクを共有しました！（プレビュー中のため疑似通知です）");
  };

  // Categories helper
  const categories = [
    { key: 'all', label: 'すべて', icon: <Sparkle size={14} /> },
    { key: 'preparation', label: 'お産の基本', icon: <CalendarBlank size={14} /> },
    { key: 'health', label: 'ママの健康', icon: <FirstAid size={14} /> },
    { key: 'life', label: '生活・ケア', icon: <Heartbeat size={14} /> },
    { key: 'relationship', label: '夫婦関係', icon: <Users size={14} /> }
  ] as const;

  // Filter columns based on category & search query
  const filteredArticles = COLUMN_ARTICLES.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.brief.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.todo.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Get icon for specific category
  const getCategoryIcon = (cat: ColumnArticle['category'], size = 18) => {
    switch(cat) {
      case 'preparation': return <CalendarBlank size={size} className="text-amber-500" />;
      case 'health': return <FirstAid size={size} className="text-rose-500" />;
      case 'life': return <Heartbeat size={size} className="text-emerald-500" />;
      case 'relationship': return <Users size={size} className="text-indigo-500" />;
    }
  };

  const getCategoryBg = (cat: ColumnArticle['category']) => {
    switch(cat) {
      case 'preparation': return 'bg-amber-50 border-amber-200 text-amber-700';
      case 'health': return 'bg-rose-50 border-rose-200 text-rose-700';
      case 'life': return 'bg-emerald-50 border-emerald-200 text-emerald-700';
      case 'relationship': return 'bg-indigo-50 border-indigo-200 text-indigo-700';
    }
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Search Input Box */}
      <div className="relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-stone-400">
          <MagnifyingGlass size={16} />
        </span>
        <input 
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="知りたい悩み・キーワードを検索する..."
          className="w-full bg-white border border-[#DCD3C7] rounded-2xl pl-10 pr-4 py-2.5 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43] placeholder-stone-400 shadow-3xs"
          id="column-search-input"
        />
        {searchQuery && (
          <button 
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 flex items-center pr-3 text-stone-400 hover:text-stone-700"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Mini Tabs for Filters Grid */}
      <div className="overflow-x-auto scrollbar-none flex gap-1.5 pb-1">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setSelectedCategory(cat.key)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-[10.5px] font-bold transition-all whitespace-nowrap cursor-pointer border ${
              selectedCategory === cat.key 
                ? 'bg-[#E06D43] text-white border-[#E06D43] shadow-3xs' 
                : 'bg-white text-stone-600 border-stone-200/80 hover:border-stone-300'
            }`}
          >
            {cat.icon}
            <span>{cat.label}</span>
          </button>
        ))}
      </div>


      {/* Articles Count & List Grid */}
      <div className="flex items-center justify-between text-[10px] text-stone-400 font-bold px-1">
        <span>記事の件数: {filteredArticles.length} 件</span>
        {searchQuery && <span>「{searchQuery}」の検索結果</span>}
      </div>

      {filteredArticles.length > 0 ? (
        <div className="grid grid-cols-1 gap-3.5">
          {filteredArticles.map((article) => {
            const isTodoDone = completedTodos[article.id];
            return (
              <motion.div
                layout
                key={article.id}
                onClick={() => setActiveArticle(article)}
                whileHover={{ scale: 1.01 }}
                className="bg-white border border-[#EFE8DF] hover:border-[#FFC7AD] hover:shadow-2xs rounded-2xl p-4 cursor-pointer shadow-3xs transition-all flex flex-col justify-between"
                id={`column-card-${article.id}`}
              >
                <div>
                  <div className="flex items-start justify-between gap-1.5 mb-2 pb-1.5 border-b border-[#FAF6F1]">
                    <span className={`text-[8.5px] font-bold px-2 py-0.5 rounded-full border ${getCategoryBg(article.category)}`}>
                      {article.categoryLabel}
                    </span>
                    <span className="text-[9px] text-[#A39180] font-sans">
                      {article.id.replace('col-', 'No. ')}
                    </span>
                  </div>
                  <h3 className="text-xs font-bold text-[#5C4D44] hover:text-[#E06D43] transition-colors leading-normal text-left">
                    {article.title}
                  </h3>
                  <p className="text-[10px] text-stone-600 leading-normal mt-2 text-justify">
                    {article.brief}
                  </p>
                </div>

                {/* Footer interactive components */}
                <div className="mt-4 pt-2 border-t border-[#FAF6F0] flex items-center justify-between text-[9px]">
                  <span className="text-[#E06D43] font-bold flex items-center gap-1">
                    📖 続きを読む
                  </span>
                  
                  {/* Miniature Quick TODO Badge */}
                  <button
                    onClick={(e) => toggleTodo(article.id, e)}
                    className={`px-2 py-0.5 rounded-full border text-[8.5px] font-bold flex items-center gap-1 transition-all ${
                      isTodoDone 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                        : 'bg-stone-50 text-stone-500 border-stone-200/80 hover:bg-stone-100'
                    }`}
                  >
                    <span>{isTodoDone ? '✓ パパ実践完了' : '📅 トゥドゥあり'}</span>
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-3xl border border-[#EFE8DF] shadow-3xs">
          <BookOpen className="w-8 h-8 text-stone-300 mx-auto mb-2" />
          <p className="text-xs text-stone-400 font-bold">該当するコラムが見つかりませんでした。</p>
          <button 
            onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
            className="text-[10px] text-[#E06D43] font-bold underline mt-2 inline-block cursor-pointer"
          >
            検索条件をクリア
          </button>
        </div>
      )}

      {/* Expanded Article Modal dialog */}
      <AnimatePresence>
        {activeArticle && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#FAF7F3] border border-[#EBE1D5] w-full max-w-md p-5 rounded-3xl shadow-xl max-h-[85vh] overflow-y-auto flex flex-col justify-between"
              id="column-detail-modal"
            >
              {/* Header */}
              <div className="flex justify-between items-center border-b border-[#ECE3D5] pb-3 mb-3 shrink-0">
                <span className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full border ${getCategoryBg(activeArticle.category)}`}>
                  {activeArticle.categoryLabel}
                </span>
                <button
                  onClick={() => setActiveArticle(null)}
                  className="text-stone-400 hover:text-stone-700 bg-white rounded-full p-1.5 border border-stone-200 cursor-pointer flex items-center justify-center shadow-3xs"
                  id="close-column-modal"
                >
                  <X size={13} />
                </button>
              </div>

              {/* Dynamic scrollable body content */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 scrollbar-none">
                <div className="text-center pb-2 border-b border-[#FAF6F1]">
                  <div className="bg-white p-3 rounded-full border border-[#ECE0D0] w-12 h-12 flex items-center justify-center mx-auto mb-2 shadow-3xs">
                    {getCategoryIcon(activeArticle.category, 22)}
                  </div>
                  <h3 className="text-xs font-bold text-[#5C4D44] leading-normal">{activeArticle.title}</h3>
                  <p className="text-[9px] text-[#A08875] mt-1 italic leading-normal text-justify">{activeArticle.brief}</p>
                </div>

                {/* Main essay text area formatted with paragraphs */}
                <div className="bg-white p-4.5 rounded-2xl border border-[#EFE8DF] shadow-3xs">
                  <p className="text-[11px] text-stone-700 leading-relaxed text-justify whitespace-pre-wrap">
                    {activeArticle.content}
                  </p>
                </div>

                {/* Highlighted Baby or Mummy's Action Box - TODO */}
                <div className="bg-[#FFF8F3] border border-[#FFDEC4] p-4 rounded-2xl space-y-2.5">
                  <div className="flex items-center gap-1.5">
                    <ClipboardText size={16} className="text-[#FF7A45]" />
                    <span className="text-[10px] font-extrabold text-[#E06D43] tracking-wide">
                      💡今日パパがやること（TODO）
                    </span>
                  </div>
                  <p className="text-[10.5px] text-stone-700 leading-relaxed text-justify">
                    {activeArticle.todo}
                  </p>
                  
                  {/* Interactive Button to Check Off the Duty */}
                  <button
                    onClick={(e) => toggleTodo(activeArticle.id, e)}
                    className={`w-full py-2 rounded-xl text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all border shrink-0 ${
                      completedTodos[activeArticle.id]
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                        : 'bg-[#E06D43] hover:bg-[#D05C33] text-white border-[#E06D43]'
                    }`}
                  >
                    <CheckSquare size={14} weight={completedTodos[activeArticle.id] ? "fill" : "regular"} />
                    <span>
                      {completedTodos[activeArticle.id] ? 'この任務を実践完了しました！' : 'このお役立ちタスクを実践する'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Bottom Actions footer bar */}
              <div className="mt-4 pt-3 border-t border-[#ECE3D5] flex gap-2 shrink-0">
                <button
                  onClick={handleShare}
                  className="flex-1 bg-white hover:bg-stone-50 text-stone-600 border border-stone-200 py-2 rounded-full text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 hover:border-stone-300"
                >
                  <ShareNetwork size={12} />
                  <span>LINEでママに共有</span>
                </button>
                <button
                  onClick={() => setActiveArticle(null)}
                  className="flex-1 bg-stone-700 hover:bg-stone-800 text-white py-2 rounded-full text-[10px] font-bold transition-all cursor-pointer"
                >
                  確認して閉じる
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
