/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PregnancyWeekInfo, Task, UserProfile } from '../types';
import { 
  Heart, 
  Calendar, 
  Warning, 
  CheckCircle, 
  ArrowRight, 
  User, 
  Baby, 
  Sparkle,
  Trophy,
  BookOpen,
  ArrowLeft,
  ChatCenteredText
} from '@phosphor-icons/react';
import { renderRubyText } from '../lib/rubyHelper';

interface HomeTabProps {
  weekInfo: PregnancyWeekInfo;
  pregnancyDay: number;
  profile: UserProfile;
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onNavigateToTab: (tab: 'diary' | 'task' | 'food' | 'settings') => void;
}

const MAMA_WISH_WORDS = [
  "ママ、毎日24時間休みなく赤ちゃんを愛して、安全に温めてくれて本当にありがとう。お腹を守る大仕事をしてくれているママは、ただ生きているだけで100点満点だよ。",
  "お皿洗いやお風呂掃除は全部終わらせてあるから、お布団でゆっくり休んでね。ママがゆっくり横になって快適に過ごせるのが、一番の赤ちゃんケアだよ。",
  "今日のごはんは、悪阻の時でも食べやすいように小分けスープを用意したよ。何も作らなくていいし、何も心配しなくて本当に大丈夫だからね。",
  "ママの体や出産、これからの生活に向けた不安な話は、どんなことでも僕に聴かせてね。僕は100%ママの味方になって、いつでも全力で支え抜くからね。",
  "お腹が大きくなってママの見た目が少しふくよかに変化しても、毎日一生懸命で、尊い命を抱く今のあなたが一番きれいで、僕は心から大好きだよ。",
  "つらい悪阻や足のむくみを、物理的に代わってあげられなくて本当にごめんね。今すぐ気持ちよくなるように腰やふくらはぎをマッサージするから、いつでも言ってね。"
];

export default function HomeTab({
  weekInfo,
  pregnancyDay,
  profile,
  tasks,
  onToggleTask,
  onNavigateToTab
}: HomeTabProps) {
  const [pulseCount, setPulseCount] = useState(0);
  const [activeWordIndex, setActiveWordIndex] = useState(0);

  // Calculate days remaining (assuming 40 weeks = 280 days total)
  const daysPassed = weekInfo.week * 7 + pregnancyDay;
  const daysRemaining = Math.max(0, 280 - daysPassed);

  // Filter tasks to show today's relevant actions
  const communicationTasks = tasks.filter(t => t.category === 'communication').slice(0, 2);
  const supportTasks = tasks.filter(t => t.category === 'support' && !t.isCompleted).slice(0, 2);
  const urgentTasks = [...communicationTasks, ...supportTasks];

  const handleBabyTap = () => {
    setPulseCount(prev => prev + 1);
  };

  const handleNextWord = () => {
    setActiveWordIndex((prev) => (prev + 1) % MAMA_WISH_WORDS.length);
  };

  const handlePrevWord = () => {
    setActiveWordIndex((prev) => (prev - 1 + MAMA_WISH_WORDS.length) % MAMA_WISH_WORDS.length);
  };

  return (
    <div className="space-y-6 pb-6">
      {/* Dynamic Header */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-[#FFF5EE] to-[#FFF0E5] border border-[#F5EFEB] rounded-2xl p-5 shadow-xs"
      >
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-sm font-semibold text-[#8B6E5B] tracking-wider uppercase">
              {profile.papaName ? `${profile.papaName}パパ` : 'プレパパ'}のマイホーム
            </h2>
            <p className="text-xs text-[#A08875] mt-0.5">
              今日も{profile.mamaName ? `${profile.mamaName}ママ` : 'ママ'}と{profile.babyNickname ? profile.babyNickname : '赤ちゃん'}のために。
            </p>
          </div>
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="bg-white/85 px-3 py-1 text-xs text-[#E06D43] font-semibold rounded-full flex items-center gap-1 border border-[#FFDFD0]"
          >
            <Sparkle size={12} weight="fill" className="text-[#FF7A45] shrink-0" />
            妊娠 {Math.floor(weekInfo.week / 4) + 1}ヶ月
          </motion.div>
        </div>

        {/* Big Counter */}
        <div className="mt-4 grid grid-cols-2 gap-4 divide-x divide-[#F3EBE4]">
          <div className="text-center py-2">
            <span className="text-xs text-[#8B7E74] block">現在の妊娠週数</span>
            <div className="text-xl font-bold text-[#5C4D44] mt-1 flex items-baseline justify-center">
              <span className="text-3xl font-extrabold text-[#E06D43] mr-1">{weekInfo.week}</span>週
              <span className="text-2xl font-bold text-[#E06D43] mr-1">{pregnancyDay}</span>日
              <span className="text-xs font-bold text-[#8B7E74] ml-1">({weekInfo.month}ヶ月)</span>
            </div>
          </div>
          <div className="text-center py-2">
            <span className="text-xs text-[#8B7E74] block">出産予定日まで残り</span>
            <div className="text-xl font-bold text-[#5C4D44] mt-1 flex items-baseline justify-center">
              あと <span className="text-3xl font-extrabold text-[#E06D43] mx-1">{daysRemaining}</span> 日
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Baby Interactive Voice Card */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white border border-[#EFE8DF] rounded-3xl p-6 shadow-sm relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#FAF5EE] rounded-full -mr-10 -mt-10 -z-10 opacity-60" />
        
        {/* Title */}
        <div className="flex items-center gap-2 mb-4">
          <div className="bg-[#FFF0E6] p-2 rounded-full border border-[#FFE0CE]">
            <Baby size={16} weight="fill" className="text-[#FF7A45]" />
          </div>
          <span className="text-xs font-bold text-[#8B7E74] tracking-wider">
            {profile.babyNickname ? profile.babyNickname : 'お腹の赤ちゃん'}からのメッセージ
          </span>
        </div>

        <div className="flex flex-col items-center gap-6 mt-2">
          {/* Animated Baby Size Illustration with clean typography instead of emojis */}
          <div className="relative flex-none">
            <motion.button
              onClick={handleBabyTap}
              whileTap={{ scale: 0.92 }}
              className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#FFF0E6] to-[#FFEAD9] border-2 border-[#FFD9C6] flex items-center justify-center shadow-md cursor-pointer relative"
              id="baby-graphic-button"
            >
              <Baby size={42} weight="fill" className="text-[#FF7A45] relative z-10" />
              
              {/* Ripple Effect on Click */}
              <AnimatePresence>
                {pulseCount > 0 && (
                  <motion.span
                    key={pulseCount}
                    initial={{ scale: 0.8, opacity: 0.8 }}
                    animate={{ scale: 1.5, opacity: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.6 }}
                    className="absolute inset-0 bg-[#FFD9C6] rounded-full"
                  />
                )}
              </AnimatePresence>
            </motion.button>

            {/* Little Heart Pulse Icon */}
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 1.8 }}
              className="absolute -bottom-1 -right-1 bg-[#FF7A45] p-1.5 rounded-full border border-white text-white shadow-xs"
            >
              <Heart size={10} weight="fill" />
            </motion.div>
          </div>

          {/* Baby's Voice Bubble */}
          <div className="w-full">
            <div className="relative bg-[#FFFBF7] border border-[#F3EAE0] rounded-2xl p-4">
              <p className="text-xs font-medium leading-relaxed text-[#5C4D44] relative z-10 text-justify">
                「{renderRubyText(weekInfo.babyVoice)}」
              </p>
              
              <div className="mt-3 pt-2.5 border-t border-[#F5EFEB] flex items-center justify-between text-[11px] text-[#A08C75]">
                <span>今の大きさ：<strong>{weekInfo.babySize.comparison}</strong> ({weekInfo.babySize.name})</span>
                <span>重さ：<strong>{weekInfo.babySize.weight}</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Baby Specs */}
        <div className="mt-5 bg-[#FAF6F0] rounded-xl p-3.5 border border-[#EFE8DF] grid grid-cols-2 gap-2 text-center text-xs text-[#7C6656]">
          <div className="border-r border-[#ECE1D4]">
            <span className="text-[10px] text-[#A08875] block">推定身長</span>
            <span className="font-semibold text-[#5C4D44] mt-0.5 inline-block">{renderRubyText(weekInfo.babySize.height)}</span>
          </div>
          <div>
            <span className="text-[10px] text-[#A08875] block">器官・全身の発達段階</span>
            <span className="font-semibold text-[#5C4D44] mt-0.5 inline-block">
              {weekInfo.week <= 11 ? renderRubyText('重要な器官の形成') : weekInfo.week <= 27 ? renderRubyText('五感・骨格の急成長') : renderRubyText('生まれる準備完了へ')}
            </span>
          </div>
        </div>
      </motion.div>

      {/* Purely Vertical Stack: Baby & Wife Medical State Info */}
      <div className="flex flex-col gap-4">
        {/* Baby detailed state */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-[#EFE8DF] rounded-2xl p-5 shadow-3xs"
        >
          <div className="flex items-center gap-2 mb-3">
            <Baby size={18} className="text-[#FF7A45]" />
            <h3 className="text-xs font-bold text-[#5C4D44] uppercase tracking-wider">今週の赤ちゃんのようす</h3>
          </div>
          <div className="text-xs text-[#7C6656] leading-relaxed">
            {renderRubyText(weekInfo.babyDetail)}
          </div>
        </motion.div>

        {/* Wife detailed state */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-[#EFE8DF] rounded-2xl p-5 shadow-3xs"
        >
          <div className="flex items-center gap-2 mb-3">
            <User size={18} className="text-[#FF7A45]" />
            <h3 className="text-xs font-bold text-[#5C4D44] uppercase tracking-wider flex items-center justify-between w-full">
              <span>ママの体の変化・心のようす</span>
              {weekInfo.week >= 16 && weekInfo.week <= 27 && (
                <span className="text-[9px] bg-[#E3F2FD] border border-[#BBDEFB] text-[#1E88E5] px-1.5 py-0.5 rounded-sm font-semibold">
                  安定期
                </span>
              )}
              {weekInfo.week >= 28 && (
                <span className="text-[9px] bg-[#FFF3E0] border border-[#FFE0B2] text-[#FB8C00] px-1.5 py-0.5 rounded-sm font-semibold animate-pulse">
                  妊娠後期・臨月
                </span>
              )}
            </h3>
          </div>
          <div className="text-xs text-[#7C6656] leading-relaxed">
            {renderRubyText(weekInfo.wifeDetail)}
          </div>
        </motion.div>
      </div>

      {/* Precautions Alerts */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#FFFDF0] border border-[#F6EAA8] rounded-2xl p-5 shadow-3xs"
      >
        <div className="flex items-center gap-2 text-[#C68D00] mb-3">
          <Warning size={16} weight="fill" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#90732A]">パパが今もっとも気をつけるべきこと</h3>
        </div>
        <ul className="space-y-2.5">
          {weekInfo.precautions.map((precaution, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-xs text-[#7D6B40] leading-relaxed">
              <span className="bg-[#FFEAA7] text-[#9A7200] w-4.5 h-4.5 rounded-full flex items-center justify-center text-[10px] font-extrabold shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <span className="text-justify">{renderRubyText(precaution)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 pt-3 border-t border-[#F2E5A8]/50 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 text-[10px] text-[#A69052]">
          <span>⚠ 妊娠中は些細なことで大きく体調変化が起きます。医師のチェックを最優先に。</span>
          <button 
            onClick={() => onNavigateToTab('food')}
            className="flex items-center gap-0.5 text-[#C68D00] font-bold hover:underline self-start sm:self-auto shrink-0"
            id="go-to-food-link"
          >
            食事注意リストを見る <ArrowRight size={10} weight="bold" />
          </button>
        </div>
      </motion.div>

      {/* NEW: Comforting Words section (moved from Task tab for focus refinement) */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-[#FFF9F6] to-[#FFF5EF] border border-[#FFDFD0] rounded-3xl p-5 shadow-3xs"
      >
        <div className="flex items-center justify-between border-b border-[#FFEBE0] pb-2 mb-3">
          <h3 className="text-xs font-bold text-[#A25232] uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
            <Heart size={16} weight="fill" className="text-[#FF7A45]" />
            ママがパパに本当に言われたい、ねぎらいの愛言葉
          </h3>
          <div className="text-[9px] text-[#C47E61] font-semibold">
            {activeWordIndex + 1} / {MAMA_WISH_WORDS.length}
          </div>
        </div>

        <div className="min-h-[80px] flex items-center justify-center p-3 bg-white/60 border border-white/60 rounded-2xl shadow-3xs">
          <p className="text-xs font-medium text-[#7A4B3A] text-justify leading-relaxed">
            {renderRubyText(MAMA_WISH_WORDS[activeWordIndex])}
          </p>
        </div>

        <div className="flex justify-end gap-1.5 mt-3">
          <button
            onClick={handlePrevWord}
            className="p-1.5 rounded-full border border-[#FFDEC4] bg-white text-[#FF7A45] hover:bg-[#FFF3EC] transition-all cursor-pointer"
            title="前へ"
            id="prev-wish-word-btn"
          >
            <ArrowLeft size={12} weight="bold" />
          </button>
          <button
            onClick={handleNextWord}
            className="p-1.5 rounded-full border border-[#FFDEC4] bg-white text-[#FF7A45] hover:bg-[#FFF3EC] transition-all cursor-pointer"
            title="次へ"
            id="next-wish-word-btn"
          >
            <ArrowRight size={12} weight="bold" />
          </button>
        </div>
      </motion.div>

      {/* Suggested Papa Tasks - Purely Vertical Layout */}
      <div className="flex flex-col gap-4">
        {/* Today's Priority Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-[#EFE8DF] rounded-2xl p-5 shadow-3xs"
        >
          <div className="flex items-center justify-between mb-3 border-b border-[#FAF6F0] pb-2">
            <h3 className="text-xs font-bold text-[#5C4D44] uppercase tracking-wider flex items-center gap-1.5">
              <Trophy size={16} className="text-[#FFAC82]" /> 今日の最優先声かけ＆家事
            </h3>
            <button 
              onClick={() => onNavigateToTab('task')}
              className="text-[10px] text-[#FF8255] font-semibold hover:underline cursor-pointer"
              id="view-all-tasks"
            >
              タスク一覧へ
            </button>
          </div>

          {urgentTasks.length === 0 ? (
            <p className="text-xs text-stone-400 py-4 text-center">すべての今日のタスクが完了しました！</p>
          ) : (
            <div className="space-y-2.5">
              {urgentTasks.map((task) => (
                <div 
                  key={task.id}
                  onClick={() => onToggleTask(task.id)}
                  className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-start gap-2.5 ${
                    task.isCompleted 
                    ? 'bg-emerald-50/50 border-emerald-100 opacity-60' 
                    : 'bg-[#FCFAF7] border-[#ECE3DA] hover:border-[#FFD0BD] hover:bg-[#FFFDFB]'
                  }`}
                  id={`home-task-item-${task.id}`}
                >
                  <button 
                    className={`w-4.5 h-4.5 rounded-full border flex-none mt-0.5 flex items-center justify-center cursor-pointer ${
                      task.isCompleted 
                      ? 'bg-emerald-500 border-emerald-500 text-white' 
                      : 'border-stone-300'
                    }`}
                  >
                    {task.isCompleted && <CheckCircle size={10} weight="fill" className="text-white" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <h4 className={`text-xs font-bold ${task.isCompleted ? 'line-through text-slate-400' : 'text-[#5C4D44]'}`}>
                      {task.title}
                    </h4>
                    <p className="text-[10px] text-[#9A8675] mt-0.5 leading-snug">
                      {task.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Recommended Tasks For Next Week */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-[#EFE8DF] rounded-2xl p-5 shadow-3xs flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-[#FAF6F0] pb-2">
              <h3 className="text-xs font-bold text-[#5C4D44] uppercase tracking-wider flex items-center gap-1.5">
                <Calendar size={16} className="text-[#FFAC82]" /> 来週おすすめのプレパパタスク
              </h3>
            </div>
            <ul className="space-y-2.5 pt-1">
              {weekInfo.recommendedTasks.map((recTask, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-[#7C6656] leading-relaxed text-justify">
                  <span className="text-[#FF7A45] mt-0.5 text-xs font-bold shrink-0">•</span>
                  <span>{renderRubyText(recTask)}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-4 pt-3 border-t border-[#FAF6F0]">
            <p className="text-[10px] text-[#A28F81] leading-relaxed">
              💡 妊娠後期になるとお産グッズ準備が本格化します。カレンダーにあらかじめ健診日程を登録して可能な範囲で一緒に行きましょう。
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
