/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile } from '../types';
import { 
  Gear, 
  FloppyDisk, 
  Warning 
} from '@phosphor-icons/react';

interface SettingsTabProps {
  profile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
  onResetData: () => void;
}

export default function SettingsTab({
  profile,
  onSaveProfile,
  onResetData
}: SettingsTabProps) {
  const [dueDate, setDueDate] = useState(profile.dueDate);
  const [papaName, setPapaName] = useState(profile.papaName);
  const [mamaName, setMamaName] = useState(profile.mamaName);
  const [babyNickname, setBabyNickname] = useState(profile.babyNickname);
  
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile({
      dueDate,
      papaName: papaName.trim(),
      mamaName: mamaName.trim(),
      babyNickname: babyNickname.trim()
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="space-y-6 pb-6">
      {/* Profile modification config form */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-[#EFE8DF] rounded-3xl p-6 shadow-3xs"
      >
        <div className="flex items-center gap-2 mb-4 border-b border-[#FAF6F0] pb-3">
          <Gear size={18} className="text-[#FF8255]" />
          <h3 className="text-xs font-bold text-[#5C4D44] uppercase tracking-wider">予定日＆お名前のカスタマイズ</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Due date input */}
            <div>
              <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                第一子の出産予定日 <span className="text-red-500">*</span>
              </label>
              <input 
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
                required
              />
              <span className="text-[9px] text-stone-400 mt-1 block leading-normal font-medium text-justify">予定日から現在の妊娠週数（0〜41週）を逆算します。</span>
            </div>

            {/* Baby's nickname */}
            <div>
              <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                赤ちゃんの胎名・愛称 <span className="text-red-500">*</span>
              </label>
              <input 
                type="text"
                value={babyNickname}
                onChange={(e) => setBabyNickname(e.target.value)}
                placeholder="例: マメちゃん、ぽん太"
                className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
                required
              />
              <span className="text-[9px] text-stone-400 mt-1 block leading-normal">お腹の中の可愛いニックネーム。メッセージが変わります。</span>
            </div>

            {/* Papa name */}
            <div>
              <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                パパのお名前（またはニックネーム）
              </label>
              <input 
                type="text"
                value={papaName}
                onChange={(e) => setPapaName(e.target.value)}
                placeholder="たかし、ゆうと など"
                className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
              />
              <span className="text-[9px] text-stone-400 mt-1 block leading-normal">アプリがママの代わりにパパへ呼びかける言葉になります。</span>
            </div>

            {/* Mama name */}
            <div>
              <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                ママのお名前（またはニックネーム）
              </label>
              <input 
                type="text"
                value={mamaName}
                onChange={(e) => setMamaName(e.target.value)}
                placeholder="かな、ゆみ など"
                className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
              />
              <span className="text-[9px] text-stone-400 mt-1 block leading-normal">奥様を応援するための文脈に差し込まれます。</span>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-[#E06D43] hover:bg-[#D05C33] text-white px-5 py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              id="save-profile-btn"
            >
              <FloppyDisk size={14} /> 設定を保存する
            </button>
          </div>

          {/* Success toast animation fallback */}
          <AnimatePresence>
            {saveSuccess && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-2.5 rounded-xl text-xs font-semibold text-center mt-2"
                id="save-success-notification"
              >
                ✓ 設定を保存しました。ホーム画面の週数情報を更新しました！
              </motion.div>
            )}
          </AnimatePresence>
        </form>
      </motion.div>

      {/* Dangerous/destructive data reset */}
      <div className="bg-[#FFF5F5] border border-red-200 rounded-3xl p-5">
        <h4 className="text-xs font-bold text-red-800 flex items-center gap-1.5 mb-1.5">
          <Warning size={16} className="text-red-600" />
          全データの初期化
        </h4>
        <p className="text-[10px] text-red-600 leading-relaxed mb-3 text-justify">
          アプリ内に保存されているすべての設定データ、追加した日記、及びタスクの進捗状況を完全にリセットします。
          このアクションは元に戻せません。
        </p>
        <button
          onClick={onResetData}
          className="bg-white border border-red-200 hover:bg-red-50 text-red-600 px-4 py-2 rounded-full text-xs font-semibold cursor-pointer transition-colors"
          id="wipe-data-btn"
        >
          全データを消去
        </button>
      </div>
    </div>
  );
}
