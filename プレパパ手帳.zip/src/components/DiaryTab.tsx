/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DiaryEntry, WifeConditionType, UserProfile } from '../types';
import { 
  Plus, 
  Trash, 
  Heart, 
  Smiley, 
  SmileyMeh, 
  SmileySad,
  Heartbeat,
  FirstAid,
  Calendar, 
  X, 
  Check, 
  Pencil,
  Trophy,
  BookOpen
} from '@phosphor-icons/react';
import { renderRubyText } from '../lib/rubyHelper';

interface DiaryTabProps {
  entries: DiaryEntry[];
  onAddEntry: (entry: Omit<DiaryEntry, 'id'>) => void;
  onEditEntry: (entry: DiaryEntry) => void;
  onDeleteEntry: (id: string) => void;
  profile: UserProfile;
}

const CONDITION_PRESETS: { type: WifeConditionType; label: string; icon: React.ReactNode; bg: string; text: string; border: string }[] = [
  { type: 'excellent', label: '穏やか・良好', icon: <Smiley size={18} weight="fill" />, bg: 'bg-[#ECFDF5]', text: 'text-[#059669]', border: 'border-[#A7F3D0]' },
  { type: 'normal', label: 'いつも通り', icon: <SmileyMeh size={18} weight="fill" />, bg: 'bg-[#F0FDF4]', text: 'text-[#15803D]', border: 'border-[#BBF7D0]' },
  { type: 'tired', label: 'だるさ・眠気', icon: <Heartbeat size={18} weight="fill" />, bg: 'bg-[#FFFBEB]', text: 'text-[#D97706]', border: 'border-[#FDE68A]' },
  { type: 'sick', label: 'つわり・吐き気', icon: <FirstAid size={18} weight="fill" />, bg: 'bg-[#FFF5F5]', text: 'text-[#E53E3E]', border: 'border-[#FEB2B2]' },
  { type: 'pain', label: 'お腹の張り・痛み', icon: <SmileySad size={18} weight="fill" />, bg: 'bg-[#FAF5FF]', text: 'text-[#7B39ED]', border: 'border-[#E9D5FF]' },
];

const PRE_PAPA_DEEDS = [
  "お皿洗い・お片付け",
  "お風呂のしゃがみ掃除",
  "重い荷物・ゴミ出し",
  "体に優しいご飯づくり",
  "背中・お腹をさする",
  "足のマッサージ・保湿",
  "お腹の赤ちゃんに声かけ",
  "一緒にゆっくりお散歩",
  "話をとことん聞いて共感"
];

export default function DiaryTab({
  entries,
  onAddEntry,
  onEditEntry,
  onDeleteEntry,
  profile
}: DiaryTabProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null);

  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [wifeCondition, setWifeCondition] = useState<WifeConditionType>('normal');
  const [wifeConditionNote, setWifeConditionNote] = useState('');
  const [happenedToday, setHappenedToday] = useState('');
  const [selectedDeeds, setSelectedDeeds] = useState<string[]>([]);

  const handleDeedToggle = (deed: string) => {
    if (selectedDeeds.includes(deed)) {
      setSelectedDeeds(prev => prev.filter(d => d !== deed));
    } else {
      setSelectedDeeds(prev => [...prev, deed]);
    }
  };

  const handleOpenNewForm = () => {
    setEditingEntry(null);
    setDate(new Date().toISOString().split('T')[0]);
    setWifeCondition('normal');
    setWifeConditionNote('');
    setHappenedToday('');
    setSelectedDeeds([]);
    setShowAddForm(true);
  };

  const handleOpenEditForm = (entry: DiaryEntry) => {
    setEditingEntry(entry);
    setDate(entry.date);
    setWifeCondition(entry.wifeCondition);
    setWifeConditionNote(entry.wifeConditionNote || '');
    setHappenedToday(entry.happenedToday);
    setSelectedDeeds(entry.papaActions || []);
    setShowAddForm(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!happenedToday.trim()) return;

    if (editingEntry) {
      onEditEntry({
        id: editingEntry.id,
        date,
        wifeCondition,
        wifeConditionNote: wifeConditionNote.trim(),
        happenedToday: happenedToday.trim(),
        papaActions: selectedDeeds
      });
    } else {
      onAddEntry({
        date,
        wifeCondition,
        wifeConditionNote: wifeConditionNote.trim(),
        happenedToday: happenedToday.trim(),
        papaActions: selectedDeeds
      });
    }

    // Reset state & Close
    setEditingEntry(null);
    setDate(new Date().toISOString().split('T')[0]);
    setWifeCondition('normal');
    setWifeConditionNote('');
    setHappenedToday('');
    setSelectedDeeds([]);
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6 pb-6">
      {/* Title Intro */}
      <div className="flex justify-between items-center bg-white border border-[#EFE8DF] rounded-2xl p-4 shadow-3xs border-b border-[#EFE8DF]">
        <div className="flex-1 pr-3">
          <h2 className="text-sm font-bold text-[#5C4D44] flex items-center gap-1.5 leading-snug">
            <BookOpen size={18} className="text-[#FF8255]" />
            ふたり日記・パパの記録
          </h2>
          <p className="text-[11px] text-[#907A68] mt-1 pr-1 text-justify leading-relaxed">
            妊娠中のママの体調変化や、パパが今日してあげられたこと、赤ちゃんのことを振り返りましょう。
          </p>
        </div>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleOpenNewForm}
          className="bg-[#E06D43] hover:bg-[#D05C33] text-white px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shrink-0 self-center"
          id="open-new-diary-btn"
        >
          <Plus size={14} /> 記録する
        </motion.button>
      </div>

      {/* Slide-in Overlay modal/panel for diary entry */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto"
            id="diary-modal-backdrop"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#FAF7F3] border border-[#EBE1D5] rounded-3xl w-full max-w-lg p-6 shadow-xl max-h-[90vh] overflow-y-auto"
              id="diary-modal"
            >
              <div className="flex justify-between items-center border-b border-[#ECE3D5] pb-3 mb-4">
                <span className="text-sm font-bold text-[#5C4D44] flex items-center gap-1.5">
                  <Pencil size={18} className="text-[#E06D43]" />
                  {editingEntry ? '日記を編集する' : '新しい日記を綴る'}
                </span>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="text-stone-400 hover:text-stone-700 bg-white rounded-full p-1 border border-stone-200 cursor-pointer"
                  id="close-diary-modal"
                >
                  <X size={14} />
                </button>
              </div>

              <form onSubmit={handleFormSubmit} className="space-y-4">
                {/* Date Selection */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">日付</label>
                  <div className="relative">
                    <input 
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
                      required
                    />
                  </div>
                </div>

                {/* Wife Status Select */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-2">
                    今日のママのご様子
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {CONDITION_PRESETS.map((p) => (
                      <button
                        key={p.type}
                        type="button"
                        onClick={() => setWifeCondition(p.type)}
                        className={`flex flex-col items-center p-2 rounded-xl border text-center transition-all cursor-pointer ${
                          wifeCondition === p.type 
                          ? `${p.bg} ${p.border} ring-2 ring-[#FFBFAB] shadow-xs` 
                          : 'bg-white border-[#DCD3C7] hover:bg-[#FAF4ED]'
                        }`}
                        id={`feeling-button-${p.type}`}
                      >
                        <span className={`mb-1 shrink-0 ${wifeCondition === p.type ? p.text : 'text-stone-500'}`}>{p.icon}</span>
                        <span className="text-[9px] font-bold text-stone-600 block leading-tight">{p.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Condition Notes */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                    ママの状況・気にしておきたい症状 <span className="text-[10px] text-[#A68F80] font-normal">(任意)</span>
                  </label>
                  <input 
                    type="text"
                    value={wifeConditionNote}
                    onChange={(e) => setWifeConditionNote(e.target.value)}
                    placeholder="例: 夕方に少しお腹の張り、匂いつわり軽減、足のむくみ"
                    className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] placeholder-stone-400 focus:outline-hidden focus:border-[#E06D43]"
                  />
                </div>

                {/* Papa's deeds checklist */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-2">
                    愛を込めて、今日できたこと <span className="text-[10px] text-[#A68F80] font-normal">(複数選択可)</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2 max-h-[140px] overflow-y-auto bg-white p-2.5 rounded-xl border border-[#DCD3C7]">
                    {PRE_PAPA_DEEDS.map((deed) => {
                      const isSelected = selectedDeeds.includes(deed);
                      return (
                        <button
                          key={deed}
                          type="button"
                          onClick={() => handleDeedToggle(deed)}
                          className={`px-2 py-1.5 rounded-lg border text-[10px] text-left transition-all flex items-center justify-between cursor-pointer ${
                            isSelected 
                            ? 'bg-[#FFF3EC] border-[#FFC7AD] text-[#E06D43] font-semibold' 
                            : 'bg-stone-50/50 border-stone-200 text-stone-600 hover:bg-stone-100/50'
                          }`}
                          id={`deed-item-${deed}`}
                        >
                          <span className="truncate">{deed}</span>
                          {isSelected && <Check size={10} className="text-[#E06D43] font-bold shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Log Reflection Text */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                    今日あったこと・パパの想い・日記本文 <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    rows={4}
                    value={happenedToday}
                    onChange={(e) => setHappenedToday(e.target.value)}
                    placeholder="例: 今日は妊婦健診に同行した。エコーで赤ちゃんが手を振ってくれているのが見えて、本当に感動した。ママも体調が良さそうでよかった。帰りは2人で好きなノンカフェインカフェに行きお茶をした。"
                    className="w-full bg-white border border-[#DCD3C7] rounded-2xl px-3 py-2 text-xs text-[#5C4D44] placeholder-stone-400 focus:outline-hidden focus:border-[#E06D43] resize-none"
                    required
                  />
                </div>

                {/* Buttons */}
                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="flex-1 border border-[#D0C5B7] hover:bg-stone-100 text-stone-600 py-2.5 rounded-full text-xs font-bold transition-colors cursor-pointer"
                  >
                    キャンセル
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-[#E06D43] hover:bg-[#D05C33] text-white py-2.5 rounded-full text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Heart size={14} weight="fill" /> 日記を保存する
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Diary Timeline Entries List */}
      <div className="space-y-4">
        {entries.length === 0 ? (
          <div className="bg-white border border-[#EFE8DF] rounded-2xl p-10 text-center space-y-3">
            <BookOpen size={48} className="mx-auto text-stone-300" />
            <p className="text-xs text-[#8C7B6E] font-medium">まだパパ手帳に日記がありません</p>
            <p className="text-[11px] text-stone-400">
              右上の「記録する」ボタンから、最初の一歩を綴ってみましょう！
            </p>
          </div>
        ) : (
          entries.map((entry) => {
            const condition = CONDITION_PRESETS.find(p => p.type === entry.wifeCondition) || CONDITION_PRESETS[1];
            
            return (
              <motion.div
                key={entry.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white border border-[#EFE8DF] rounded-2xl p-5 shadow-2xs relative group"
                id={`diary-card-${entry.id}`}
              >
                {/* Actions: Edit and Trash */}
                <div className="absolute right-4 top-4 flex items-center gap-1">
                  {/* Edit button */}
                  <button
                    onClick={() => handleOpenEditForm(entry)}
                    className="p-1.5 bg-white hover:bg-stone-100 text-[#E06D43] hover:text-[#D05C33] rounded-full border border-stone-200 cursor-pointer transition-colors"
                    title="日記編集"
                    id={`edit-diary-${entry.id}`}
                  >
                    <Pencil size={14} />
                  </button>

                  {/* Delete button */}
                  <button
                    onClick={() => onDeleteEntry(entry.id)}
                    className="p-1.5 bg-white hover:bg-red-50 text-stone-400 hover:text-red-500 rounded-full border border-stone-200 cursor-pointer transition-colors"
                    title="日記削除"
                    id={`delete-diary-${entry.id}`}
                  >
                    <Trash size={14} />
                  </button>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-3 border-b border-[#FAF6F1] mb-3 pr-16 md:pr-18">
                  <div className="flex items-center gap-2">
                    <div className="bg-[#FFF0E8] p-1.5 rounded-full text-[#E06D43]">
                      <Calendar size={14} />
                    </div>
                    <span className="text-xs font-bold text-[#5C4D44]">{entry.date}</span>
                    {profile.papaName && (
                      <span className="text-[10px] bg-[#FAF6F0] px-2 py-0.5 rounded-md text-[#8C7D70] border border-[#EFE8DF] font-semibold">
                        {profile.papaName}の言葉
                      </span>
                    )}
                  </div>

                  {/* Mother's status badge */}
                  <div className={`text-[10px] px-2.5 py-1 rounded-full border flex items-center gap-1 font-semibold ${condition.bg} ${condition.border} ${condition.text}`}>
                    <span className="shrink-0">{condition.icon}</span>
                    <span>ママの様子: {condition.label}</span>
                  </div>
                </div>

                {/* Body paragraph */}
                <p className="text-xs text-[#5C4D44] leading-relaxed text-justify whitespace-pre-wrap">
                  {renderRubyText(entry.happenedToday)}
                </p>

                {/* Condition note if available */}
                {entry.wifeConditionNote && (
                  <div className="mt-3 text-[10px] text-[#A28E7D] bg-[#FAF4ED] p-2 rounded-xl flex items-center gap-1 text-justify">
                    <span className="font-bold shrink-0 text-[#E06D43]">症状・気づき:</span>
                    <span>{renderRubyText(entry.wifeConditionNote)}</span>
                  </div>
                )}

                {/* Papa Deeds items registered */}
                {entry.papaActions && entry.papaActions.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-[#FAF6F0]">
                    <span className="text-[9px] font-bold text-[#8C7D70] tracking-wider block mb-1.5 uppercase flex items-center gap-1">
                      <Trophy size={12} className="text-[#FFBC99]" /> パパの思いやり行動
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {entry.papaActions.map((act) => (
                        <span 
                          key={act}
                          className="bg-[#FFFDFB] border border-[#EFE5DB] text-[9px] text-[#E06D43] px-2 py-0.5 rounded-md font-semibold"
                        >
                          ✓ {act}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )
          })
        )}
      </div>
    </div>
  );
}
