/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, TaskCategory, UserProfile } from '../types';
import { 
  CheckSquare, 
  Square, 
  Plus, 
  Trash, 
  FileText, 
  Handshake, 
  ShoppingBag, 
  ChatCenteredText, 
  MagnifyingGlass, 
  X,
  Sparkle
} from '@phosphor-icons/react';
import { renderRubyText } from '../lib/rubyHelper';

interface TaskTabProps {
  tasks: Task[];
  onToggleTask: (id: string) => void;
  onAddTask: (title: string, category: TaskCategory, description: string) => void;
  onDeleteTask: (id: string) => void;
  profile: UserProfile;
}

const CATEGORY_MAP: Record<TaskCategory, { label: string, icon: React.ReactNode, bg: string, text: string, border: string }> = {
  paperwork: {
    label: "手続き・書類",
    icon: <FileText size={14} />,
    bg: "bg-[#F0FDF4]",
    text: "text-[#166534]",
    border: "border-[#BBF7D0]"
  },
  support: {
    label: "ママのサポート",
    icon: <Handshake size={14} />,
    bg: "bg-[#FFF1F2]",
    text: "text-[#9F1239]",
    border: "border-[#FECDD3]"
  },
  preparation: {
    label: "プレパパ準備",
    icon: <ShoppingBag size={14} />,
    bg: "bg-[#EFF6FF]",
    text: "text-[#1E40AF]",
    border: "border-[#BFDBFE]"
  },
  communication: {
    label: "毎日の声掛け・共感",
    icon: <ChatCenteredText size={14} />,
    bg: "bg-[#FAF5FF]",
    text: "text-[#6B21A8]",
    border: "border-[#E9D5FF]"
  }
};

export default function TaskTab({
  tasks,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  profile
}: TaskTabProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | TaskCategory>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Custom Task input fields
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<TaskCategory>('support');
  const [newDesc, setNewDesc] = useState('');

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  const completedCount = tasks.filter(t => t.isCompleted).length;
  const progressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddTask(newTitle.trim(), newCategory, newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setShowAddModal(false);
  };

  const filteredTasks = tasks.filter(task => {
    const matchesCategory = activeFilter === 'all' || task.category === activeFilter;
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          task.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-6">
      {/* Title block with progress container */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-[#EFE8DF] rounded-3xl p-5 shadow-3xs"
      >
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-sm font-bold text-[#5C4D44] flex items-center gap-1.5">
              <CheckSquare size={18} className="text-[#FF8255]" />
              プレパパお仕事リスト
            </h2>
            <p className="text-[11px] text-[#907A68] mt-1 pr-4">
              妊娠期間にしてあげたい「パパのアクションリスト（手続き・ママのサポート・声掛け）」です。
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="shrink-0 bg-[#E06D43] hover:bg-[#D05C33] text-white px-4 py-2 rounded-full text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
            id="open-custom-task-btn"
          >
            <Plus size={14} /> タスクを追加
          </button>
        </div>

        {/* Real-time Progress Bar */}
        <div className="mt-5 pt-3 border-t border-[#FAF6F1]">
          <div className="flex justify-between items-center text-[10px] text-[#8C7D70] font-bold mb-1.5">
            <span>タスクの進捗状況：{completedCount} / {tasks.length} 完了</span>
            <span className="text-[#E06D43]">{progressPercent}%</span>
          </div>
          <div className="w-full bg-[#FAF6F0] rounded-full h-2 overflow-hidden border border-[#ECE0D1]">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              className="bg-gradient-to-r from-[#FFA27A] to-[#E06D43] h-full"
            />
          </div>
        </div>
      </motion.div>

      {/* Task Filters & Search Box */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A59485]">
            <MagnifyingGlass size={14} />
          </span>
          <input
            type="text"
            placeholder="タスクをキーワードで検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[#EBE1D4] text-xs text-[#5C4D44] placeholder-stone-400 rounded-xl pl-9 pr-3 py-2.5 focus:outline-hidden focus:border-[#E06D43]"
            id="task-search-input"
          />
        </div>

        {/* Custom Category Horizontal Filters */}
        <div className="flex gap-1 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
              activeFilter === 'all'
              ? 'bg-[#E06D43] text-white shadow-xs'
              : 'bg-white border border-[#EBE1D4] text-stone-600 hover:bg-[#FFFDFB]'
            }`}
            id="filter-all"
          >
            すべてみる
          </button>
          {(Object.keys(CATEGORY_MAP) as TaskCategory[]).map((catKey) => {
            const config = CATEGORY_MAP[catKey];
            const isActive = activeFilter === catKey;
            return (
              <button
                key={catKey}
                onClick={() => setActiveFilter(catKey)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                  ? `${config.bg} ${config.border} ${config.text} ring-2 ring-transparent shadow-3xs font-extrabold`
                  : 'bg-white border border-[#EBE1D4] text-stone-600 hover:bg-[#FFFDFB]'
                }`}
                id={`filter-${catKey}`}
              >
                {config.icon}
                <span>{config.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tasks Entries List */}
      <div className="space-y-3 pb-8">
        {filteredTasks.length === 0 ? (
          <div className="bg-white border border-[#EFE8DF] rounded-2xl p-10 text-center space-y-2">
            <p className="text-xs text-[#8C7A6B] font-medium">該当するアクションが見つかりません</p>
            <p className="text-[10px] text-stone-400">
              検索ワードを変更するか、別のカテゴリーを選択、または新しいタスクを追加してください。
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const catInfo = CATEGORY_MAP[task.category];
            return (
              <motion.div
                key={task.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`bg-white border border-[#EFE8DF] rounded-2xl p-4.5 shadow-3xs flex items-start gap-3 transition-colors ${
                  task.isCompleted ? 'bg-[#FCFAF7]/60 opacity-60' : 'hover:border-[#FFD0BD]'
                }`}
                id={`task-card-container-${task.id}`}
              >
                {/* Custom Checkbox Action on click */}
                <button
                  type="button"
                  onClick={() => onToggleTask(task.id)}
                  className="mt-0.5 shrink-0 text-slate-300 hover:text-[#E06D43] transition-colors cursor-pointer"
                  id={`checkbox-${task.id}`}
                >
                  {task.isCompleted ? (
                    <CheckSquare size={20} weight="fill" className="text-emerald-500 bg-white rounded-md" />
                  ) : (
                    <Square size={20} className="text-stone-400 bg-white rounded-md" />
                  )}
                </button>

                {/* Info Text */}
                <div className="flex-1 min-w-0" onClick={() => onToggleTask(task.id)}>
                  <div className="flex flex-wrap items-center gap-2">
                    <h4 className={`text-xs font-bold leading-snug cursor-pointer select-none ${
                       task.isCompleted ? 'line-through text-[#8C7D70]' : 'text-[#4A3C31]'
                    }`}>
                      {renderRubyText(task.title)}
                    </h4>
                    {/* Tiny category label */}
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${catInfo.bg} ${catInfo.border} ${catInfo.text}`}>
                      {catInfo.label}
                    </span>
                  </div>
                  <p className="text-[10px] text-stone-500 mt-1 leading-relaxed cursor-pointer select-none whitespace-pre-line text-justify">
                    {renderRubyText(task.description)}
                  </p>
                </div>

                {/* If custom user-created task, show Delete option */}
                {task.isCustom && (
                  <button
                    onClick={() => onDeleteTask(task.id)}
                    className="text-stone-300 hover:text-red-500 p-1.5 rounded-full hover:bg-stone-50 cursor-pointer self-center"
                    title="タスク削除"
                    id={`delete-task-btn-${task.id}`}
                  >
                    <Trash size={14} />
                  </button>
                )}
              </motion.div>
            );
          })
        )}
      </div>

      {/* Add Task Modal dialog state */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#FAF7F3] border border-[#EBE1D5] w-full max-w-md p-6 rounded-3xl shadow-xl"
              id="add-task-modal"
            >
              <div className="flex justify-between items-center border-b border-[#ECE3D5] pb-3 mb-4">
                <span className="text-sm font-bold text-[#5C4D44] flex items-center gap-1.5">
                  <CheckSquare size={20} weight="fill" className="text-[#E06D43]" />
                  カスタムタスクを追加
                </span>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="text-stone-400 hover:text-stone-700 bg-white rounded-full p-1 border border-stone-200 cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>

              <form onSubmit={handleCreateTask} className="space-y-4">
                {/* Title */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                    タスク内容 <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="例: マタニティスクールを夫婦で予約する"
                    className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] placeholder-stone-400 focus:outline-hidden focus:border-[#E06D43]"
                    required
                  />
                </div>

                {/* Category Selection */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                    カテゴリー
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as TaskCategory)}
                    className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] focus:outline-hidden focus:border-[#E06D43]"
                  >
                    <option value="support">ママのサポート（家事代行・マッサージ・付き添い）</option>
                    <option value="paperwork">手続き・書類整理（育休申請・児童手当予習）</option>
                    <option value="preparation">プレパパ準備（ベビーカー選定・お産用品購入）</option>
                    <option value="communication">毎日の声掛け（ねぎらい・お腹ケア）</option>
                  </select>
                </div>

                {/* Description */}
                <div>
                  <label className="text-xs font-semibold text-[#8B7B6E] block mb-1">
                    メモ・詳細情報 <span className="text-[10px] text-[#A68F80] font-normal">(任意)</span>
                  </label>
                  <textarea
                    rows={3}
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="例: 火曜日に最寄りの保健所のHPから予約ボタンを押す。健診日と被らないように調整。"
                    className="w-full bg-white border border-[#DCD3C7] rounded-xl px-3 py-2 text-xs text-[#5C4D44] placeholder-stone-400 focus:outline-hidden focus:border-[#E06D43] resize-none"
                  />
                </div>

                {/* Buttons */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 border border-[#D0C5B7] hover:bg-stone-100 text-stone-600 py-2.5 rounded-full text-xs font-bold transition-colors cursor-pointer"
                  >
                    キャンセル
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-[#E06D43] hover:bg-[#D05C33] text-white py-2.5 rounded-full text-xs font-bold transition-colors cursor-pointer"
                  >
                    追加する
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
