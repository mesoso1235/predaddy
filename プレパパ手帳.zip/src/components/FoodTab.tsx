/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle, 
  Warning, 
  XCircle, 
  Info, 
  MagnifyingGlass, 
  Coffee,
  Prohibit,
  X,
  Egg,
  Heartbeat
} from '@phosphor-icons/react';
import { renderRubyText } from '../lib/rubyHelper';

interface FoodItem {
  id: string;
  name: string;
  category: 'safe' | 'caution' | 'danger';
  reason: string;
  whyDetails: string;
  substance?: string; // e.g. "トキソプラズマ", "リステリア菌", "カフェイン", "葉酸"
}

const FOOD_ITEMS_DB: FoodItem[] = [
  // Safe / recommended category
  {
    id: "f-s1",
    name: "ブロッコリー・ほうれん草",
    category: "safe",
    reason: "「葉酸」と「鉄分」が豊富で、赤ちゃんの脳や脊髄の神経管の発達を支援します。",
    whyDetails: "特に妊娠初期（妊娠前から12週頃）までは、神経発達のために葉酸が必須です。また、妊婦さんは血液量が約1.5倍に増大するため貧血になりやすく、積極的に鉄分をとることが必須です。",
    substance: "葉酸・鉄分"
  },
  {
    id: "f-s2",
    name: "ヨーグルト・牛乳・小魚",
    category: "safe",
    reason: "赤ちゃんの骨や歯の基礎を固める「カルシウム」の素晴らしい供給源です。",
    whyDetails: "骨量維持のために十分な量を摂取しましょう。低脂肪なものを選ぶと体重過多対策にもグッド。また、小魚類は、ビタミンDも一緒に摂れるためカルシウム吸収を早めます。しっかりと加熱滅菌された日本の大手乳業メーカーのものであればリステリア菌のリスクはなく極めて安全です。",
    substance: "カルシウム"
  },
  {
    id: "f-s3",
    name: "大豆製品（納豆・豆腐）",
    category: "safe",
    reason: "良質な植物性タンパク質、マグネシウム、鉄分、カルシウムが総合的に補給できます。",
    whyDetails: "納豆に含まれる納豆キナーゼや大豆イソフラボンは、体調を無理なく保護します。ただし、イソフラボンサプリなどでの極端な過剰摂取は避け、あくまで通常の食事（1日1〜2パック程度）として美味しくいただくのが、体に最適な摂取量です。",
    substance: "たんぱく質"
  },
  {
    id: "f-s4",
    name: "鶏胸肉・ささみ、白身魚",
    category: "safe",
    reason: "低脂質・高栄養な動物性良質タンパク質。ママの体力増強と、赤ちゃんの筋肉・身体器官の組成に最適です。",
    whyDetails: "消化吸収が非常に良いため、胃が圧迫されてたくさん食べられない中後期でも、体に負担をかけずに栄養補充ができます。中心部まで完全にピンク色がなくなるよう、しっかりと加熱（75度、1分以上）してお召し上がりください。",
    substance: "良質タンパク質"
  },
  
  // Caution category
  {
    id: "f-c1",
    name: "コーヒー・紅茶・緑茶",
    category: "caution",
    reason: "「カフェイン」は胎盤を通って赤ちゃんに届きます。過剰摂取は低出生体重児のリスクを高めます。",
    whyDetails: "1日にコーヒーなら1〜2杯（カフェイン200mg以下）までなら問題ないとWHOで発表されています。心配な場合は、パパが率先して「カフェインレス・デカフェ」やハーブティー、ルイボスティーなどの、美味しくて目が覚める代わりに寝つきを良くするお茶を用意してあげましょう。",
    substance: "カフェイン"
  },
  {
    id: "f-c2",
    name: "マグロ（本マグロ、メバチ）・金目鯛",
    category: "caution",
    reason: "食物連鎖の頂点にいる大型深海魚は、体内に「メチル水銀」を蓄積しています。赤ちゃんの発達への影響が懸念されます。",
    whyDetails: "厚生労働省のガイドラインにより、本マグロ、キオマグロ、キンメダイ、ムツなどの大型魚は、1回に食べる量（80g程度）を「週に1回まで」に留めることが推奨されています。なお、ツナ缶、サケ、サバ、アジ、イワシなどは水銀含有量がごくわずかなので、毎日食べても全く心配ありません。",
    substance: "メチル水銀"
  },
  {
    id: "f-c3",
    name: "鶏・豚・牛のレバー",
    category: "caution",
    reason: "鉄分は豊富ですが、動物性「ビタミンA（レチノール）」が極端に過剰です。赤ちゃんの奇形リスクが生じます。",
    whyDetails: "特に器官がつくられる妊娠初期（15週頃まで）は、レバーやうなぎ（レチノールが極めて高濃度）の毎日の常食は控えましょう。時々一切れ食べる程度なら無害ですが、サプリ等でビタミンAを過剰摂取する事態は厳重に警戒してください。植物性のビタミンA（人参などのβカロテン）はいくら食べても無害です。",
    substance: "ビタミンA"
  },
  {
    id: "f-c4",
    name: "香辛料（カレー、唐辛子）・塩分の高い食事",
    category: "caution",
    reason: "胃腸への刺激が強く下痢を引き起こしたり、お母さんの妊娠高血圧症候群、むくみの直接的な原因になります。",
    whyDetails: "カレーなどスパイスが効いた食べ物は食欲増進を助けますが、ほどほどに。また塩分の取りすぎは「妊婦健診」で血圧の上昇を指摘され、入院の原因にも繋がります。パパは、お味噌汁をだしを効かせた薄味にするなど、優しい減塩サポート料理で活躍しましょう。",
    substance: "塩分・刺激物"
  },

  // Danger category
  {
    id: "f-d1",
    name: "生肉、生ハム、馬刺し、ローストビーフ",
    category: "danger",
    reason: "「トキソプラズマ原虫」に感染する危険性が非常に高いです。赤ちゃんの脳や視神経に先天性障害を起こします。",
    whyDetails: "トキソプラズマは生肉に寄生する原虫です。ママが妊娠中に初めて感染すると、胎盤から赤ちゃんに移行し、「先天性トキソプラズマ症」（水頭症、視力障害など）を引き起こする可能性があります。ローストビーフや生ハムのような低温でのレア肉もしゃぶしゃぶの加熱不十分なものも全てNG。中心部が完全に変色するまでよくソテーしたお肉だけを食べるようにさせてください。",
    substance: "トキソプラズマ"
  },
  {
    id: "f-d2",
    name: "ナチュラルチーズ（非加熱・青カビ等）、生乳",
    category: "danger",
    reason: "「リステリア菌」による食中毒をひきおこす確率が極めて高く、低用量でも流産や精神不全・死産の最たる原因になります。",
    whyDetails: "リステリア菌は、冷蔵庫の4℃程度の低温でも繁殖する恐ろしい強い耐性を持つ細菌です。加熱処理（殺菌処理）されていない輸入品のナチュラルチーズ（ブリー、カマンベール、ブルーチーズ等）や無殺菌のヤギ乳・生乳は、絶対にママに与えないでください。なお、プロセスチーズや、しっかりピザのように熱を加えて全体がフツフツと泡立つまで加熱されたチーズであればリステリアは死滅するので安全です。",
    substance: "リステリア菌"
  },
  {
    id: "f-d3",
    name: "アルコール飲料（お酒全般）",
    category: "danger",
    reason: "赤ちゃんに「胎児性アルコール症候群」を引き起こします。知的障害や発育遅延、特徴的な顔貌などのリスクが確実になります。",
    whyDetails: "アルコールは分子が極小のため、胎盤のフィルターを100％素通りして赤ちゃんに届きます。赤ちゃんにはお酒を分解する酵素がまだありません。安全なアルコール摂取量は「一切存在しない」と医学的に結論づけられています。一口だからと勧めたりせず、できればパパも一緒に禁酒やお付き合い程度の飲酒に留める強固な連帯感をとってください。",
    substance: "アルコール"
  },
  {
    id: "f-d4",
    name: "生の貝類、生牡蠣、生卵",
    category: "danger",
    reason: "「サルモネラ菌」や「ノロウイルス」による激しい食中毒・嘔吐・高熱のリスクがあり、子宮収縮運動を招きます。",
    whyDetails: "直接胎児への奇形リスクなどは少ないものの、ママが激しい嘔吐や下痢になると、急激な脱水状態を招き、それに伴うホルモン収縮でお腹が張り、最悪「前期破水」や「流・早産」の原因になります。妊娠中は薬の服用が厳しく制限されるため、市販の中毒薬も安易に使えません。牡蠣などの貝類や卵は、絶対に100%しっかりと火を通した状態（目玉焼きではなく、中まで固いゆで卵など）で与えるのが基本です。",
    substance: "ノロ・サルモネラ"
  }
];

export default function FoodTab() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'safe' | 'caution' | 'danger'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<FoodItem | null>(null);

  const filteredFoods = FOOD_ITEMS_DB.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.reason.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (item.substance && item.substance.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-6">
      {/* Header Intro and disclaimer */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-[#EFE8DF] rounded-3xl p-5 shadow-3xs"
      >
        <div className="flex items-center gap-2 mb-2">
          <div className="bg-[#FFF0E6] p-2 rounded-xl border border-[#FFE0CE] text-[#FF7A45] flex items-center justify-center">
            <Coffee size={20} weight="fill" />
          </div>
          <h2 className="text-sm font-bold text-[#5C4D44]">{renderRubyText("パパが守る安心・安全なお食事ノート")}</h2>
        </div>
        <p className="text-[11px] text-[#907A68] leading-relaxed text-justify">
          妊娠中はお腹の赤ちゃんの健康を守るため、食事への細心の配慮が必要です。
          産婦人科や医学ガイドラインのもっとも正確な基準に基づき、安心して食卓を彩るためのリストを作成しました。
        </p>
        <div className="mt-3.5 bg-[#FFF9F6] border border-[#FFDEC4] p-3 rounded-2xl flex items-start gap-2.5 text-[10px] text-[#C05D3D] leading-relaxed text-justify">
          <Info size={16} weight="fill" className="mt-0.5 shrink-0 text-[#E06D43]" />
          <span>
            <strong>重要：</strong>一部の細菌（リステリア菌やトキソプラズマ原虫）は、通常の健康な大人には軽い風邪症状しか出しませんが、お腹の胎児には重篤な影響を及ぼすことがあります。「一口だけなら大丈夫」と考えず、加熱の徹底などパパが優しく目を光らせて、美味しい安全なご飯をサーブしましょう。
          </span>
        </div>
      </motion.div>

      {/* Interactive Tabs & Search */}
      <div className="space-y-3">
        {/* Search */}
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
            <MagnifyingGlass size={16} />
          </span>
          <input
            type="text"
            placeholder="お肉、カフェイン、水銀、葉酸などの食材・物質検索..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-[#EBE1D4] text-xs text-[#5C4D44] placeholder-stone-400 rounded-xl pl-9.5 pr-3 py-2.5 focus:outline-hidden focus:border-[#E06D43]"
            id="food-search-input"
          />
        </div>

        {/* Categories togglers */}
        <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-thin">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-all ${
              activeCategory === 'all'
              ? 'bg-[#E06D43] text-white shadow-xs'
              : 'bg-white border border-[#EBE1D4] text-stone-600 hover:bg-[#FFFDFB]'
            }`}
          >
            すべて表示
          </button>
          
          <button
            onClick={() => setActiveCategory('safe')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap flex items-center gap-1.5 cursor-pointer transition-all ${
              activeCategory === 'safe'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800 font-extrabold shadow-3xs'
              : 'bg-white border border-[#EBE1D4] text-[#A08875] hover:bg-[#FFFDFB]'
            }`}
          >
            <CheckCircle size={14} className="text-emerald-500" />
            積極的お勧め食
          </button>

          <button
            onClick={() => setActiveCategory('caution')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap flex items-center gap-1.5 cursor-pointer transition-all ${
              activeCategory === 'caution'
              ? 'bg-amber-50 border border-amber-200 text-amber-800 font-extrabold shadow-3xs'
              : 'bg-white border border-[#EBE1D4] text-[#A08875] hover:bg-[#FFFDFB]'
            }`}
          >
            <Warning size={14} className="text-amber-500" />
            食べる量に注意
          </button>

          <button
            onClick={() => setActiveCategory('danger')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap flex items-center gap-1.5 cursor-pointer transition-all ${
              activeCategory === 'danger'
              ? 'bg-rose-50 border border-rose-200 text-rose-800 font-extrabold shadow-3xs'
              : 'bg-white border border-[#EBE1D4] text-[#A08875] hover:bg-[#FFFDFB]'
            }`}
          >
            <Prohibit size={14} className="text-rose-500" />
            絶対に避ける
          </button>
        </div>
      </div>

      {/* Grid of Results */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredFoods.map((item) => {
          let cardBg = "bg-white";
          let borderCol = "border-[#EFE8DF]";
          let textBadge = "bg-[#FCFAF7] text-stone-500 border-stone-200";
          let iconComponent = null;

          if (item.category === 'safe') {
            cardBg = "bg-[#FCFDF9]";
            borderCol = "border-[#E6EDDC] hover:border-emerald-300";
            textBadge = "bg-emerald-50 text-emerald-700 border-emerald-100";
            iconComponent = <CheckCircle size={16} className="text-emerald-500 shrink-0" />;
          } else if (item.category === 'caution') {
            cardBg = "bg-[#FFFDF5]";
            borderCol = "border-[#F6EAA8] hover:border-amber-300";
            textBadge = "bg-amber-50 text-amber-700 border-amber-100";
            iconComponent = <Warning size={16} className="text-amber-500 shrink-0" />;
          } else if (item.category === 'danger') {
            cardBg = "bg-[#FFFBFA]";
            borderCol = "border-[#FED7D7] hover:border-rose-300";
            textBadge = "bg-rose-50 text-rose-700 border-rose-100 animate-pulse";
            iconComponent = <Prohibit size={16} className="text-rose-500 shrink-0" />;
          }

          return (
            <motion.div
              layout
              key={item.id}
              onClick={() => setSelectedItem(item)}
              whileHover={{ scale: 1.01 }}
              className={`${cardBg} border ${borderCol} rounded-2xl p-4.5 cursor-pointer shadow-3xs select-none transition-all flex flex-col justify-between`}
              id={`food-card-${item.id}`}
            >
              <div>
                <div className="flex items-start justify-between gap-2.5 pb-2 border-b border-[#FAF6F1] mb-2.5">
                  <h3 className="text-xs font-extrabold text-[#5C4D44] flex items-center gap-1.5 leading-snug">
                    {iconComponent}
                    {renderRubyText(item.name)}
                  </h3>
                  {item.substance && (
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${textBadge}`}>
                      {renderRubyText(item.substance)}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-stone-600 leading-relaxed text-left text-justify">
                  {renderRubyText(item.reason)}
                </p>
              </div>

              <div className="mt-4 pt-2.5 border-t border-[#FAF6F0] flex items-center justify-between text-[9px] text-[#A39180] font-medium">
                <span className="flex items-center gap-1 text-[#E06D43] font-bold">
                  <Heartbeat size={12} className="text-[#E06D43]" /> 各種データを詳しく読む
                </span>
                <span>タップで詳細を展開</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Expanded detailed modal on tap */}
      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#FAF7F3] border border-[#EBE1D5] w-full max-w-md p-6 rounded-3xl shadow-xl overflow-hidden max-h-[90vh] overflow-y-auto"
              id="food-detail-modal"
            >
              <div className="flex justify-between items-center border-b border-[#ECE3D5] pb-3 mb-4">
                <span className="text-xs font-bold text-[#8C7D70] tracking-wider uppercase flex items-center gap-1.5">
                  <Heartbeat size={16} className="text-[#E06D43]" /> 医学的理由とアドバイス
                </span>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="text-stone-400 hover:text-stone-700 bg-white rounded-full p-1 border border-stone-200 cursor-pointer flex items-center justify-center"
                  id="close-food-modal"
                >
                  <X size={14} className="text-[#E06D43]" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-white border border-[#EFE8DF]">
                  {selectedItem.category === 'safe' && <CheckCircle size={20} className="text-emerald-500" />}
                  {selectedItem.category === 'caution' && <Warning size={20} className="text-amber-500" />}
                  {selectedItem.category === 'danger' && <Prohibit size={20} className="text-rose-500" />}
                  <div>
                    <h4 className="text-xs font-bold text-[#5C4D44] leading-none">{renderRubyText(selectedItem.name)}</h4>
                    {selectedItem.substance && (
                      <span className="text-[9px] font-bold text-[#E06D43] bg-orange-50 px-1.5 py-0.5 rounded-sm border border-orange-100 inline-block mt-1.5">
                        主要対象: {renderRubyText(selectedItem.substance)}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <h5 className="text-[10px] font-bold text-[#947E6C] mb-1">【一般的な概要】</h5>
                  <p className="text-xs text-stone-600 leading-relaxed bg-white/70 p-3 rounded-xl border border-stone-100 text-justify">
                    {renderRubyText(selectedItem.reason)}
                  </p>
                </div>

                <div>
                  <h5 className="text-[10px] font-bold text-red-700 mb-1">【医師・産科医の詳しい見解と対策】</h5>
                  <p className="text-[11px] text-stone-700 leading-relaxed bg-white p-4.5 rounded-2xl border border-[#EFE8DF] shadow-3xs text-justify">
                    {renderRubyText(selectedItem.whyDetails)}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedItem(null)}
                  className="w-full bg-[#E06D43] hover:bg-[#D05C33] text-white py-2.5 rounded-full text-xs font-bold transition-colors cursor-pointer text-center"
                >
                  確認して閉じる
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
