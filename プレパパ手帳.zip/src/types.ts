/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserProfile {
  dueDate: string; // YYYY-MM-DD
  papaName: string;
  mamaName: string;
  babyNickname: string;
}

export type WifeConditionType = 'excellent' | 'normal' | 'tired' | 'sick' | 'pain';

export interface DiaryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  wifeCondition: WifeConditionType;
  wifeConditionNote: string;
  happenedToday: string;
  papaActions: string[];
}

export type TaskCategory = 'paperwork' | 'support' | 'preparation' | 'communication';

export interface Task {
  id: string;
  category: TaskCategory;
  title: string;
  description: string;
  isCompleted: boolean;
  isCustom?: boolean;
}

export interface BabySizeInfo {
  name: string;        // e.g. "いちご", "レモン"
  comparison: string;  // e.g. "いちご1個分"
  weight: string;      // e.g. "約10〜20g"
  height: string;      // e.g. "約7〜9cm"
  icon: string;        // icon emoji e.g. "🍓"
}

export interface PregnancyWeekInfo {
  week: number;
  month: number;
  babySize: BabySizeInfo;
  babyVoice: string;   // e.g. "パパいつもありがとう！今はレモンくらいの大きさだよ。"
  babyDetail: string;  // Medical-grade natural Japanese description of the baby
  wifeDetail: string;  // Medical-grade natural Japanese description of the wife's state
  precautions: string[]; // Important precautions for papa to keep in mind
  recommendedTasks: string[]; // Recommended things for papa to do
}
