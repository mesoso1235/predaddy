/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

// Phonetic mapping for automatic ruby annotations (ルビ振り)
// We map non-standard or medical terminology and complex kanji with appropriate small furigana.
const RUBY_MAP: { word: string; ruby: string }[] = [
  { word: "妊娠検査薬", ruby: "にんしんけんさやく" },
  { word: "器官形成期", ruby: "きかんけいせいき" },
  { word: "吸てつ反射", ruby: "きゅうてつはんしゃ" },
  { word: "妊娠高血圧症候群", ruby: "にんしんこうけつあつしょうこうぐん" },
  { word: "妊娠糖尿病", ruby: "にんしんとうにょうびょう" },
  { word: "仰臥位低血圧症候群", ruby: "ぎょうがいていけつあつしょうこうぐん" },
  { word: "低血圧症", ruby: "ていけつあつしょう" },
  { word: "前駆陣痛", ruby: "ぜんくじんつう" },
  { word: "産褥期", ruby: "さんじょくき" },
  { word: "安産祈願", ruby: "あんざんきがん" },
  { word: "両親学級", ruby: "りょうしんがっきゅう" },
  { word: "静脈瘤", ruby: "じょうみゃくりゅう" },
  { word: "こむら返り", ruby: "こむらがえり" },
  { word: "胎嚢", ruby: "たいのう" },
  { word: "胎芽", ruby: "たいが" },
  { word: "胎盤", ruby: "たいばん" },
  { word: "胎動", ruby: "たいどう" },
  { word: "羊水", ruby: "ようすい" },
  { word: "恥骨", ruby: "ちこつ" },
  { word: "正期産", ruby: "せいきさん" },
  { word: "破水", ruby: "はすい" },
  { word: "戌の日", ruby: "いぬのひ" },
  { word: "悪阻", ruby: "つわり" },
  { word: "つわり", ruby: "悪阻" },
  { word: "心拍", ruby: "しんぱく" },
  { word: "骨盤底筋群", ruby: "こつばんていきんぐん" },
  { word: "尿漏れ", ruby: "にょうもれ" },
  { word: "横隔膜", ruby: "おうかくまく" },
  { word: "悪露", ruby: "おろ" },
  { word: "陣痛", ruby: "じんつう" },
  { word: "分娩", ruby: "ぶんべん" },
  { word: "初乳", ruby: "しょにゅう" },
  { word: "沐浴", ruby: "もくよく" },
  { word: "流産", ruby: "りゅうざん" },
  { word: "早産", ruby: "そうざん" },
];

/**
 * Automates pristine ruby annotations into text elements while keeping proper word wrapping.
 */
export function renderRubyText(text: string): React.ReactNode {
  return text;
}
