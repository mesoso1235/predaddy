/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  House, 
  BookOpen, 
  CheckSquare, 
  ForkKnife, 
  Gear, 
  Heart,
  Baby,
  Newspaper
} from '@phosphor-icons/react';

// Types and Components
import { UserProfile, DiaryEntry, Task, TaskCategory } from './types';
import { getPregnancyWeekInfo, presetTasks } from './data/pregnancyData';
import HomeTab from './components/HomeTab';
import ColumnTab from './components/ColumnTab';
import DiaryTab from './components/DiaryTab';
import TaskTab from './components/TaskTab';
import FoodTab from './components/FoodTab';
import SettingsTab from './components/SettingsTab';

// Helper to determine a default due date 115 days from today (around week 23 of pregnancy)
function getDefaultDueDate(): string {
  const today = new Date();
  const targetDate = new Date(today);
  targetDate.setDate(today.getDate() + 115);
  return targetDate.toISOString().split('T')[0];
}

// Calculate pregnancy week and day from due date
function calculatePregnancyWeekAndDay(dueDateStr: string): { week: number, day: number } {
  const today = new Date();
  const dueDate = new Date(dueDateStr);
  
  // Clear times for pure calendar date comparison
  today.setHours(0, 0, 0, 0);
  dueDate.setHours(0, 0, 0, 0);
  
  const diffTime = dueDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  // Pregnancy is 280 days (40 weeks) total
  const elapsedDays = Math.max(0, 280 - diffDays);
  const week = Math.floor(elapsedDays / 7);
  const day = elapsedDays % 7;
  
  // Cap between 0 and 41 weeks, day between 0 and 6
  return {
    week: Math.max(0, Math.min(41, week)),
    day: Math.max(0, Math.min(6, day))
  };
}

// Key for storage persistence
const STORAGE_KEY_PROFILE = 'prepapa_profile_v1';
const STORAGE_KEY_DIARY = 'prepapa_diary_v1';
const STORAGE_KEY_TASKS = 'prepapa_tasks_v1';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'column' | 'diary' | 'task' | 'food' | 'settings'>('home');

  // 1. User Profile local State
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PROFILE);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved profile', e);
      }
    }
    return {
      dueDate: getDefaultDueDate(),
      papaName: "たかし",
      mamaName: "かな",
      babyNickname: "マメちゃん"
    };
  });

  // 2. Diary Entries local State
  const [diaryEntries, setDiaryEntries] = useState<DiaryEntry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_DIARY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse diary entries', e);
      }
    }
    // Heartwarming default seed entries to avoid empty screens
    return [
      {
        id: "seed-1",
        date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 15 days ago
        wifeCondition: "excellent",
        wifeConditionNote: "つわりが完全に明けて食事をおいしそうに完食！",
        happenedToday: "初めて胎動がわかった記念すべき日。ママがお腹にそっと手を当てて「ポコポコした！」と教えてくれた。僕も手をあてると、手のひらにかすかにトントンと小さな鼓動のような生命の躍動が伝わってきて、思わず涙が出そうになるほど感動した。ママ、24時間赤ちゃんを育んでくれて、本当に本当にありがとう！",
        papaActions: ["お皿洗い・お片付け", "お腹の赤ちゃんに声かけ"]
      },
      {
        id: "seed-2",
        date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 5 days ago
        wifeCondition: "tired",
        wifeConditionNote: "夕方から足が張って、腰痛が少し辛そうだった",
        happenedToday: "お産の時にも活躍するチャイルドシートとベビーベッドについての評判をネットで調査。お腹が大きくなって足元が見えづらくなってきたので、玄関の靴を片付けて履きやすいスニーカーを手前にセット。夜、お風呂上がりにママの足を太ももからふくらはぎに向けてゆっくりマッサージした。「すごく軽くなった、ありがとう」と言ってもらえるだけで最高に幸せだ。",
        papaActions: ["足のマッサージ・保湿", "重い荷物・ゴミ出し", "話をとことん聞いて共感"]
      }
    ];
  });

  // 3. Tasks list local State
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_TASKS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse tasks', e);
      }
    }
    // Seed with comprehensive checklist compiled from expert parenting sources
    return Object.keys(presetTasks).map((key) => ({
      id: key,
      ...presetTasks[key],
      isCompleted: false
    }));
  });

  // Persist edits back to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DIARY, JSON.stringify(diaryEntries));
  }, [diaryEntries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_TASKS, JSON.stringify(tasks));
  }, [tasks]);

  // Derived Values
  const { week: pregnancyWeek, day: pregnancyDay } = calculatePregnancyWeekAndDay(profile.dueDate);
  const weekInfo = getPregnancyWeekInfo(pregnancyWeek);

  // Handlers
  const handleSaveProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
  };

  const handleToggleTask = (id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, isCompleted: !task.isCompleted } : task
    ));
  };

  const handleAddTask = (title: string, category: TaskCategory, description: string) => {
    const newTask: Task = {
      id: `custom-task-${Date.now()}`,
      category,
      title,
      description,
      isCompleted: false,
      isCustom: true
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const handleAddDiaryEntry = (newEntry: Omit<DiaryEntry, 'id'>) => {
    const freshEntry: DiaryEntry = {
      id: `diary-${Date.now()}`,
      ...newEntry
    };
    setDiaryEntries(prev => [freshEntry, ...prev]);
  };

  const handleEditDiaryEntry = (updatedEntry: DiaryEntry) => {
    setDiaryEntries(prev => prev.map(entry => 
      entry.id === updatedEntry.id ? updatedEntry : entry
    ));
  };

  const handleDeleteDiaryEntry = (id: string) => {
    if (window.confirm("この記述日記を削除してもよろしいですか？")) {
      setDiaryEntries(prev => prev.filter(entry => entry.id !== id));
    }
  };

  const handleResetData = () => {
    if (window.confirm("アプリ内のすべての日記、設定、進捗データを消去して初期状態に戻します。よろしいですか？")) {
      localStorage.removeItem(STORAGE_KEY_PROFILE);
      localStorage.removeItem(STORAGE_KEY_DIARY);
      localStorage.removeItem(STORAGE_KEY_TASKS);
      
      // Reset state to default
      setProfile({
        dueDate: getDefaultDueDate(),
        papaName: "たかし",
        mamaName: "かな",
        babyNickname: "マメちゃん"
      });
      setDiaryEntries([]);
      setTasks(Object.keys(presetTasks).map((key) => ({
        id: key,
        ...presetTasks[key],
        isCompleted: false
      })));
      setCurrentTab('home');
    }
  };

  return (
    <div id="app-root-container" className="min-h-screen bg-[#FAF6F0] text-[#5C4D44] flex flex-col antialiased">
      {/* Upper Navigation Header Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#EFE8DF] px-4 py-3.5 shadow-3xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-[#FFF0E6] p-2 rounded-xl border border-[#FFDFC4] text-[#E06D43] flex items-center justify-center">
              <Baby size={20} weight="fill" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-[#5C4D44] tracking-tight">プレパパ手帳</h1>
              <p className="text-[10px] text-[#A08C75] font-semibold mt-0.5">ママとマメちゃんのための愛のノート</p>
            </div>
          </div>
          <div className="flex items-center gap-1 bg-[#FFF9F5] border border-[#FFDEC4] px-2.5 py-1 rounded-full">
            <Heart size={12} weight="fill" className="text-[#FF7A45] animate-pulse shrink-0" />
            <span className="text-[10px] font-extrabold text-[#FF7A45]">胎齢 {pregnancyWeek}週{pregnancyDay}日</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 pt-5 pb-24 overflow-x-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.15 }}
            className="w-full"
          >
            {currentTab === 'home' && (
              <HomeTab 
                weekInfo={weekInfo}
                pregnancyDay={pregnancyDay}
                profile={profile}
                tasks={tasks}
                onToggleTask={handleToggleTask}
                onNavigateToTab={(tab) => setCurrentTab(tab)}
              />
            )}
            
            {currentTab === 'diary' && (
              <DiaryTab 
                entries={diaryEntries}
                onAddEntry={handleAddDiaryEntry}
                onEditEntry={handleEditDiaryEntry}
                onDeleteEntry={handleDeleteDiaryEntry}
                profile={profile}
              />
            )}
            
            {currentTab === 'task' && (
              <TaskTab 
                tasks={tasks}
                onToggleTask={handleToggleTask}
                onAddTask={handleAddTask}
                onDeleteTask={handleDeleteTask}
                profile={profile}
              />
            )}
            
            {currentTab === 'food' && (
              <FoodTab />
            )}

            {currentTab === 'column' && (
              <ColumnTab />
            )}
            
            {currentTab === 'settings' && (
              <SettingsTab 
                profile={profile}
                onSaveProfile={handleSaveProfile}
                onResetData={handleResetData}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Persistent Mobile Bottom Navigation Bar (Minimum Target-size 44px) */}
      <nav id="bottom-navigation-bar" className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-[#EFE8DF] px-2 shadow-xl">
        <div className="max-w-md mx-auto grid grid-cols-6 gap-0.5 h-16">
          {/* Tab 1: Home */}
          <button
            onClick={() => setCurrentTab('home')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'home' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-home"
            style={{ minHeight: '44px' }}
          >
            <House size={20} weight={currentTab === 'home' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">ホーム</span>
            {currentTab === 'home' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>

          {/* Tab 2: Diary */}
          <button
            onClick={() => setCurrentTab('diary')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'diary' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-diary"
            style={{ minHeight: '44px' }}
          >
            <BookOpen size={20} weight={currentTab === 'diary' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">日記</span>
            {currentTab === 'diary' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>

          {/* Tab 3: Tasks */}
          <button
            onClick={() => setCurrentTab('task')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'task' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-task"
            style={{ minHeight: '44px' }}
          >
            <CheckSquare size={20} weight={currentTab === 'task' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">タスク</span>
            {currentTab === 'task' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>

          {/* Tab 4: Food */}
          <button
            onClick={() => setCurrentTab('food')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'food' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-food"
            style={{ minHeight: '44px' }}
          >
            <ForkKnife size={20} weight={currentTab === 'food' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">食べ物</span>
            {currentTab === 'food' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>

          {/* Tab 5: Column */}
          <button
            onClick={() => setCurrentTab('column')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'column' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-column"
            style={{ minHeight: '44px' }}
          >
            <Newspaper size={20} weight={currentTab === 'column' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">コラム</span>
            {currentTab === 'column' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>

          {/* Tab 6: Settings */}
          <button
            onClick={() => setCurrentTab('settings')}
            className={`flex flex-col items-center justify-center gap-1 transition-all h-full w-full cursor-pointer rounded-xl relative ${
              currentTab === 'settings' ? 'text-[#E06D43] font-bold' : 'text-stone-400 hover:text-stone-600'
            }`}
            id="tab-button-settings"
            style={{ minHeight: '44px' }}
          >
            <Gear size={20} weight={currentTab === 'settings' ? 'fill' : 'regular'} />
            <span className="text-[9px] tracking-tight">設定</span>
            {currentTab === 'settings' && (
              <motion.div layoutId="activeTabIndicator" className="absolute bottom-1 w-5 h-0.5 bg-[#E06D43] rounded-full" />
            )}
          </button>
        </div>
      </nav>
    </div>
  );
}
